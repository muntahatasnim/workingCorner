function signup()
{
   var name=document.getElementsByName("username");
   var email=document.getElementsByName("Email");
   var pass=document.getElementsByName("password");

  

 firebase.auth().createUserWithEmailAndPassword(email, pass).then(function(user) {
	    var user = firebase.auth().currentUser;
	    var userId = user.uid;

	    user.updateProfile({
		  displayName: name
		}).then(function() {
		  // Update successful.
		}).catch(function(error) {
		  // An error happened.
		});

		firebase.database().ref('users/' + userId).set({
			Name: name,
			Email : email,
			UserID : userId
		})
		.then(function() {
			firebase.auth().signOut();
			window.location = "sign_in.html";
		})
		.catch(function(error) {
			var errorCode = error.code;
			var errorMessage = error.message;
			window.alert("Error Code: " + errorCode);
			window.alert("Error Message: " + errorMessage);
		});
	}, function(error) {
	 	var errorCode = error.code;
		var errorMessage = error.message;
	  	window.alert("Error Code: " + errorCode);
	  	window.alert("Error Message: " + errorMessage);		
	});	
}

